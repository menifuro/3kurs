import kotlin.math.sqrt
import kotlin.math.pow

// Класс Точка
data class Point(val x: Double, val y: Double)

// Функция для вычисления расстояния между двумя точками
fun getDistance(point1: Point, point2: Point): Double {
    return sqrt((point2.x - point1.x).pow(2) + (point2.y - point1.y).pow(2))
}

fun main() {
    // Ввод количества точек
    print("Введите количество точек: ")
    val pointCount = readLine()!!.toInt()

    // Проверка корректности ввода
    if (pointCount < 3) {
        println("Количество точек должно быть больше двух.")
        return
    }

    // Ввод координат точек
    val points = Array(pointCount) {
        println("Точка ${it + 1}:")
        print("X = ")
        val x = readLine()!!.toDouble()
        print("Y = ")
        val y = readLine()!!.toDouble()
        Point(x, y)
    }

    // Нахождение минимального и максимального расстояний
    var minDistance = Double.MAX_VALUE
    var maxDistance = Double.MIN_VALUE
    for (i in 0 until pointCount - 1) {
        for (j in i + 1 until pointCount) {
            val currentDistance = getDistance(points[i], points[j])
            minDistance = minOf(minDistance, currentDistance)
            maxDistance = maxOf(maxDistance, currentDistance)
        }
    }

    // Вывод результата
    println("Минимальное расстояние: $minDistance")
    println("Максимальное расстояние: $maxDistance")
}

