import kotlin.math.abs

// класс ьочка
data class Point(val x: Double, val y: Double)

// класс треугольник
class Triangle(val a: Point, val b: Point, val c: Point) {
    fun isPointInside(point: Point): Boolean {
        // вычисление площади треугольника
        val area = 0.5 * abs((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y))

        // вычисление площадей трех треугольников, образованных точкой и двумя вершинами исходного треугольника
        val area1 = 0.5 * abs((b.x - point.x) * (c.y - point.y) - (c.x - point.x) * (b.y - point.y))
        val area2 = 0.5 * abs((c.x - point.x) * (a.y - point.y) - (a.x - point.x) * (c.y - point.y))
        val area3 = 0.5 * abs((a.x - point.x) * (b.y - point.y) - (b.x - point.x) * (a.y - point.y))

        // сумма площадей трех треугольников должна быть равна площади исходного треугольника, если точка находится внутри
        return abs(area - area1 - area2 - area3) < 0.0001
    }
}

// получения ввода числа, с обработкой ошибок
fun getDoubleInput(): Double {
    while (true) {
        print("Введите число: ")
        val input = readLine()
        if (input != null && input.toDoubleOrNull() != null) {
            return input.toDouble()
        } else {
            println("Неверный ввод. Попробуйте снова.")
        }
    }
}

fun main() {
    // ввод координат точки
    println("Введите координаты точки:")
    print("X = ")
    val pointX = getDoubleInput()
    print("Y = ")
    val pointY = getDoubleInput()
    val point = Point(pointX, pointY)

    // ввод координат вершин треугольника
    println("Введите координаты вершин треугольника:")
    print("Вершина A: X = ")
    val aX = getDoubleInput()
    print("Y = ")
    val aY = getDoubleInput()
    val a = Point(aX, aY)
    print("Вершина B: X = ")
    val bX = getDoubleInput()
    print("Y = ")
    val bY = getDoubleInput()
    val b = Point(bX, bY)
    print("Вершина C: X = ")
    val cX = getDoubleInput()
    print("Y = ")
    val cY = getDoubleInput()
    val c = Point(cX, cY)
    val triangle = Triangle(a, b, c)

    // проверка нахождения точки внутри треугольника
    if (triangle.isPointInside(point)) {
        println("Точка находится внутри треугольника.")
    } else {
        println("Точка находится вне треугольника.")
    }
}

