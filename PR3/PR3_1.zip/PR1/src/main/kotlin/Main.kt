fun main() {
    println("Введите количество строк: ")
    val rows = readLine()!!.toInt()
    println("Введите количество столбцов: ")
    val cols = readLine()!!.toInt()

    val arr = Array(rows) { Array(cols) { 0 } }

    println("Введите ${rows * cols} трехзначных чисел:")
    for (i in 0 until rows) {
        for (j in 0 until cols) {
            arr[i][j] = readLine()!!.toInt()
        }
    }

    // Используем HashSet для хранения уникальных цифр
    val uniqueDigits = HashSet<Int>()

    for (i in 0 until rows) {
        for (j in 0 until cols) {
            var num = arr[i][j]
            while (num > 0) {
                uniqueDigits.add(num % 10)
                num /= 10
            }
        }
    }

    println("Двумерный массив:")
    for (i in 0 until rows) {
        for (j in 0 until cols) {
            print("${arr[i][j]}t")
        }
        println()
    }

    println("В массиве использовано ${uniqueDigits.size} различных цифр.")
}