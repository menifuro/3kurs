fun main() {
    // Создание массива с алфавитом и номерами
    val alphabet = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЫЪЭЮЯ".toCharArray()
    val numbers = intArrayOf(21, 13, 4, 20, 22, 1, 25, 12, 24, 14, 2, 28, 9, 23, 3, 29, 6, 16, 15, 11, 26, 5, 30, 27, 8, 18, 10, 33, 31, 32, 19, 7, 17)

    // Создание HashMap для сопоставления символов и их номеров
    val charToNumber = HashMap<Char, Int>()
    for (i in alphabet.indices) {
        charToNumber[alphabet[i]] = numbers[i]
    }

    print("Введите 1 для шифрования, 2 для дешифрования: ")
    val choice = readLine()!!.toInt()

    print("Введите текст: ")
    val text = readLine()!!.uppercase()

    print("Введите ключевое слово: ")
    val keyword = readLine()!!.uppercase()

    var result = ""
    var shift = 0

    if (choice == 1) {
        // Шифрование
        for (i in text.indices) {
            if (text[i].isLetter()) {
                shift = charToNumber[text[i]] + charToNumber[keyword[i % keyword.length]]
                shift %= 33
                for (j in numbers.indices) {
                    if (numbers[j] == shift) {
                        result += alphabet[j]
                        break
                    }
                }
            } else {
                result += text[i]
            }
        }
    } else if (choice == 2) {
        // Дешифрование
        for (i in text.indices) {
            if (text[i].isLetter()) {
                shift = charToNumber[text[i]] - charToNumber[keyword[i % keyword.length]]
                if (shift < 0) {
                    shift += 33
                }
                for (j in numbers.indices) {
                    if (numbers[j] == shift) {
                        result += alphabet[j]
                        break
                    }
                }
            } else {
                result += text[i]
            }
        }
    } else {
        println("Некорректный выбор.")
        return
    }

    println("Результат: $result")
}