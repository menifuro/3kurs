fun main() {
    print("Введите слова (введите пустую строку для завершения ввода):n")
    val words = mutableListOf<String>()
    while (true) {
        val word = readLine()
        if (word.isNullOrEmpty()) {
            break
        }
        words.add(word.lowercase())
    }

    // Создание HashMap для группировки слов
    val groups = HashMap<String, MutableList<String>>()

    for (word in words) {
        val sortedWord = word.toCharArray().sortedArray().joinToString("")
        if (groups.containsKey(sortedWord)) {
            groups[sortedWord]!!.add(word)
        } else {
            groups[sortedWord] = mutableListOf(word)
        }
    }

    println("Слова, сгруппированные по признаку "состоят из одинаковых букв":")
    for ((key, value) in groups) {
        println(value.joinToString(" "))
    }
}