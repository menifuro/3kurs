fun main() {
    print("Введите размер первого массива: ")
    val n1 = readLine()!!.toInt()
    print("Введите элементы первого массива (через пробел): ")
    val arr1 = readLine()!!.split(" ").map { it.toInt() }

    print("Введите размер второго массива: ")
    val n2 = readLine()!!.toInt()
    print("Введите элементы второго массива (через пробел): ")
    val arr2 = readLine()!!.split(" ").map { it.toInt() }

    // Сортировка массивов для удобства поиска пересечений
    arr1.sort()
    arr2.sort()

    val intersection = mutableListOf<Int>()
    var i = 0
    var j = 0

    while (i < arr1.size && j < arr2.size) {
        if (arr1[i] < arr2[j]) {
            i++
        } else if (arr1[i] > arr2[j]) {
            j++
        } else {
            intersection.add(arr1[i])
            i++
            j++
        }
    }

    println("Пересечение массивов: ${intersection.joinToString(" ")}")
}