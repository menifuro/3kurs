fun main() {
    val arr = Array(5) { IntArray(5) }

    println("Введите элементы массива 5x5:")
    for (i in 0 until 5) {
        for (j in 0 until 5) {
            arr[i][j] = readLine()!!.toInt()
        }
    }

    var isSymmetric = true

    for (i in 0 until 5) {
        for (j in i + 1 until 5) {
            if (arr[i][j] != arr[j][i]) {
                isSymmetric = false
                break
            }
        }
        if (!isSymmetric) {
            break
        }
    }

    if (isSymmetric) {
        println("Массив симметричен относительно главной диагонали.")
    } else {
        println("Массив не симметричен относительно главной диагонали.")
    }
}