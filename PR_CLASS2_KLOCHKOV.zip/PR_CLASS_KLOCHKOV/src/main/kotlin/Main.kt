import kotlin.math.sqrt
import kotlin.math.pow

// класс точки
data class Point(val x: Double, val y: Double)

// вычисления расстояния между двумя точками
fun getDistance(point1: Point, point2: Point): Double {
    return sqrt((point2.x - point1.x).pow(2) + (point2.y - point1.y).pow(2))
}

fun main() {
    // ввод координат первой точки
    println("Введите координаты первой точки:")
    print("X = ")
    val x1 = readLine()!!.toDouble()
    print("Y = ")
    val y1 = readLine()!!.toDouble()
    val point1 = Point(x1, y1)

    // ввод координат второй точки
    println("Введите координаты второй точки:")
    print("X = ")
    val x2 = readLine()!!.toDouble()
    print("Y = ")
    val y2 = readLine()!!.toDouble()
    val point2 = Point(x2, y2)

    // вычисление расстояния
    val distance = getDistance(point1, point2)
    println("Расстояние между точками: $distance")
}
